# Ermi Birr — personal birr tracker (Android)

Developed by Ermias Tadesse · 0984193465 · Telegram @ermit01 · ermitech2023@gmail.com

## Get the APK (pick one)

**A. Android Studio (easiest on a PC)**
1. Install Android Studio, choose *Open* and select this folder.
2. Wait for Gradle sync, then *Build > Build APK(s)*.
3. APK appears in `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install.

**B. GitHub (no PC tools needed)**
1. Create a new private repo on github.com and upload everything in this folder (keep the `.github` folder).
2. Open the *Actions* tab > *Build Ermi Birr APK* > *Run workflow*.
3. When finished, download the `ErmiBirr-APK` artifact (zip) and install the APK.

## What is inside
- Fingerprint / face / phone-password check every time the app opens or returns from background.
- Reads SMS only from known Ethiopian bank/wallet senders (list in `Banks.kt`), saves to a local Room (SQLite) database on the phone.
- Notification for every transaction (amount, who, balance, total balance), and a daily summary at 8:30 AM (= 2:30 Ethiopian clock) by default; change it in Settings.
- Refresh button on Home and Transactions; re-scans the SMS inbox and rates.
- Exchange rates: whenever there is internet (when the app opens and every 12 hours in the background) the app asks the National Bank of Ethiopia for the daily indicative rate and saves one value per day. If NBE cannot be reached it saves a market rate instead and labels it "Market rate (NBE not reachable)". The NBE call is in `NbeSource` in `Data.kt`.
- Analytics: daily/monthly spending chart, categories, spending by bank, daily exchange rates (USD, EUR, GBP, SAR, AED, CNY) with a day-by-day chart and converter.
- Scan tab: QR scanner that warns if the link is not an official verification site and opens verify.et.
- Ermi AI: offline assistant that answers from your own data (balance, spending, income, biggest expense, forecast, saving tips, currency conversion).

## Bank & wallet logos (already added)
Logos live in `app/src/main/res/drawable-nodpi/`:
- `bank_<id>.png` — square icon shown in the app (ids are the first column in `Banks.kt`). Included: `cbe`, `cbebirr`, `telebirr`, `boa`, `awash`, `dashen`, `zemen`, `hibret`, `oromia`, `amhara`, `amole`, `chapa`, `ethiotelecom`.
- `bankfull_<id>.png` — full wordmark versions (and `bankfull_cbebirr_tile.png`, the purple CBE Birr tile) for wide placements.
To add another bank logo, save a square PNG as `bank_<id>.png` there. No code change is needed. Banks without a logo show a coloured badge with their code.

## Ledger tab (new)
- **Debts**: who owes you / who you owe, optional due date, one-tap SMS or Telegram reminder (opens your SMS/Telegram app with the message ready).
- **Equb & Idir**: contribution amount, rounds, your payout turn, next payment date and payout date (Gregorian + Ethiopian calendar), "Mark paid" progress.
- Anything due in the next 3 days (or late) is added to the daily summary notification.
- The Home screen shows today's Ethiopian date.

## If a bank is not detected
SMS sender names differ per bank. Open `Banks.kt` and add the sender name shown in your messages app to that bank's `aliases` list (upper-case, letters and digits only).
