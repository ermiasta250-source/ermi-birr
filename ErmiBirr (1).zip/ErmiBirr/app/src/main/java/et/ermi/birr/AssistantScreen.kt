package et.ermi.birr

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Msg(val text: String, val mine: Boolean)

@Composable
fun AssistantScreen(vm: MainVm) {
    val txns by vm.txns.collectAsState()
    val msgs = remember {
        mutableStateListOf(
            Msg("Selam! I'm Ermi, your money assistant. Ask me about your balance, spending, income, exchange rates or how to save. Everything is calculated on your phone.", false)
        )
    }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    fun send(q: String) {
        if (q.isBlank()) return
        msgs.add(Msg(q.trim(), true))
        msgs.add(Msg(Assistant.answer(q, txns, vm.rates), false))
        input = ""
    }
    LaunchedEffect(msgs.size) { listState.animateScrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("Ermi AI", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text("Ask anything about your money", color = Color.Gray, fontSize = 13.sp)
        LazyColumn(Modifier.weight(1f).padding(vertical = 8.dp), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.mine) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(
                        m.text,
                        color = if (m.mine) Color.White else Color(0xFF14201B),
                        modifier = Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (m.mine) Green else Color.White).padding(12.dp)
                    )
                }
            }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 6.dp)) {
            items(listOf("My balance", "Spent this week", "Where does my money go?", "Biggest expense", "How can I save?", "100 USD in birr", "Will my money last?")) { s ->
                Text(
                    s, fontSize = 12.sp, color = Green,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFFE6F2EC))
                        .clickable { send(s) }.padding(horizontal = 12.dp, vertical = 7.dp)
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, singleLine = true,
                placeholder = { Text("Ask Ermi…") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(24.dp)
            )
            IconButton(onClick = { send(input) }) { Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = Green) }
        }
    }
}
