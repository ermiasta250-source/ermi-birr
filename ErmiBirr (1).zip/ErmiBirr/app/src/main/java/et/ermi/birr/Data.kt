package et.ermi.birr

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val ADDIS: ZoneId = ZoneId.of("Africa/Addis_Ababa")

@Entity(tableName = "txns", indices = [Index(value = ["hash"], unique = true)])
data class Txn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hash: String,
    val bankId: String,
    val isIncome: Boolean,
    val amount: Double,
    val balance: Double?,
    val counterparty: String,
    val ref: String?,
    val category: String,
    val time: Long,
    val raw: String
)

@Dao
interface TxnDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(t: Txn): Long

    @Query("SELECT * FROM txns ORDER BY time DESC")
    fun all(): Flow<List<Txn>>

    @Query("SELECT * FROM txns ORDER BY time DESC")
    suspend fun allNow(): List<Txn>

    @Query("UPDATE txns SET category = :c WHERE id = :id")
    suspend fun setCategory(id: Long, c: String)

    @Query("DELETE FROM txns")
    suspend fun clear()
}

/** v1 -> v2: adds the debt ledger and Equb/Idir tables. Existing transactions are kept. */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `debts` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`person` TEXT NOT NULL, `amount` REAL NOT NULL, `theyOweMe` INTEGER NOT NULL, " +
                "`note` TEXT NOT NULL, `phone` TEXT NOT NULL, `created` INTEGER NOT NULL, " +
                "`due` INTEGER, `settled` INTEGER NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `saving_groups` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`kind` TEXT NOT NULL, `name` TEXT NOT NULL, `amount` REAL NOT NULL, `members` INTEGER NOT NULL, " +
                "`myTurn` INTEGER NOT NULL, `startDay` TEXT NOT NULL, `periodDays` INTEGER NOT NULL, " +
                "`paidRounds` INTEGER NOT NULL)"
        )
    }
}

@Database(entities = [Txn::class, Debt::class, SavingGroup::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): TxnDao
    abstract fun debts(): DebtDao
    abstract fun groups(): GroupDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "ermibirr.db")
                .addMigrations(MIGRATION_1_2)
                .build().also { inst = it }
        }
    }
}

/** Small settings store (all local). */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("ermi", Context.MODE_PRIVATE)
    fun summaryHour(c: Context) = sp(c).getInt("sh", 8)
    fun summaryMin(c: Context) = sp(c).getInt("sm", 30)
    fun setSummary(c: Context, h: Int, m: Int) = sp(c).edit().putInt("sh", h).putInt("sm", m).apply()
    fun hide(c: Context) = sp(c).getBoolean("hide", false)
    fun setHide(c: Context, v: Boolean) = sp(c).edit().putBoolean("hide", v).apply()
    fun ratesJson(c: Context): String = sp(c).getString("hist", "[]") ?: "[]"
    fun saveRates(c: Context, json: String) = sp(c).edit().putString("hist", json).apply()
}

/** [source] is "NBE" (National Bank of Ethiopia indicative rate) or "MKT" (market-rate fallback). */
data class DayRates(val day: String, val etbPer: Map<String, Double>, val source: String = "MKT", val published: String = "")

/**
 * Daily exchange-rate history stored on the phone. Every time there is internet (app open, plus a background
 * job every 12 h) it asks the National Bank of Ethiopia first and only falls back to a market rate when the
 * NBE data cannot be reached. Each saved day remembers which source it came from.
 */
object Rates {
    val codes = listOf("USD", "EUR", "GBP", "SAR", "AED", "CNY")

    fun history(c: Context): List<DayRates> = try {
        val arr = JSONArray(Prefs.ratesJson(c))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            DayRates(
                o.getString("d"),
                codes.mapNotNull { k -> if (o.has(k)) k to o.getDouble(k) else null }.toMap(),
                o.optString("s", "MKT"), o.optString("p", "")
            )
        }
    } catch (e: Exception) { emptyList() }

    fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.setRequestProperty("Accept", "application/json")
        try {
            if (conn.responseCode !in 200..299) throw java.io.IOException("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    /** Fallback: market rate, ETB per 1 unit of each currency. */
    private fun fetchMarket(): Map<String, Double> {
        val r = JSONObject(httpGet("https://open.er-api.com/v6/latest/USD")).getJSONObject("rates")
        val etb = r.getDouble("ETB")
        return codes.associateWith { k -> if (k == "USD") etb else etb / r.getDouble(k) }
    }

    suspend fun refresh(c: Context): Boolean = withContext(Dispatchers.IO) {
        val market = try { fetchMarket() } catch (e: Exception) { null }
        val nbe = try { NbeSource.fetch(market?.get("USD")) } catch (e: Exception) { null }
        if (market == null && nbe == null) return@withContext false

        val today = LocalDate.now(ADDIS).toString()
        val old = history(c)
        val existing = old.firstOrNull { it.day == today }
        // Never replace an official NBE value saved today with a fallback value.
        if (nbe == null && existing != null && existing.source == "NBE") return@withContext true

        val src = if (nbe != null) "NBE" else "MKT"
        val entry = JSONObject().put("d", today).put("s", src).put("p", nbe?.published ?: "")
        codes.forEach { k ->
            val v = nbe?.rates?.get(k) ?: market?.get(k)
            if (v != null) entry.put(k, v)
        }
        val arr = JSONArray()
        old.filter { it.day != today }.takeLast(59).forEach { d ->
            val o = JSONObject().put("d", d.day).put("s", d.source).put("p", d.published)
            d.etbPer.forEach { (k, v) -> o.put(k, v) }
            arr.put(o)
        }
        arr.put(entry)
        Prefs.saveRates(c, arr.toString())
        true
    }
}

data class NbeTable(val published: String, val rates: Map<String, Double>)

/**
 * National Bank of Ethiopia "Daily Indicative Exchange Rates" (nbe.gov.et/exchange/indicatives-rates).
 * The NBE page fills its table from a JSON call, so the app asks that same call for today and then
 * a few days back (no table is published on weekends and holidays). Rates are ETB per 1 unit
 * (mid-rate, or the average of buying and selling when no mid-rate is given).
 */
object NbeSource {
    private const val API = "https://api.nbe.gov.et/api/filter-exchange-rates?date="

    /** [marketUsd] is only used as a sanity check so a mis-read table is never shown as the official rate. */
    fun fetch(marketUsd: Double?): NbeTable? {
        for (back in 0..4) {
            val day = LocalDate.now(ADDIS).minusDays(back.toLong())
            val text = try { Rates.httpGet(API + day) } catch (e: Exception) { return null }
            val rates = parse(text) ?: continue
            val usd = rates["USD"] ?: continue
            if (!plausible(usd, marketUsd)) return null
            return NbeTable(day.toString(), rates)
        }
        return null
    }

    private fun plausible(usd: Double, marketUsd: Double?): Boolean =
        if (marketUsd != null && marketUsd > 0) usd / marketUsd in 0.75..1.33 else usd in 10.0..2000.0

    /** Reads any JSON shape that lists objects with a 3-letter currency code and buying/selling/mid values. */
    fun parse(text: String): Map<String, Double>? {
        val root = try { JSONTokener(text).nextValue() } catch (e: Exception) { return null }
        val out = HashMap<String, Double>()
        fun walk(n: Any?) {
            when (n) {
                is JSONArray -> for (i in 0 until n.length()) walk(n.opt(i))
                is JSONObject -> {
                    val code = listOf("currency_code", "currencyCode", "code", "currency", "symbol", "iso")
                        .firstNotNullOfOrNull { k ->
                            n.optString(k, "").trim().uppercase().takeIf { it.length == 3 && it.all { ch -> ch.isLetter() } }
                        }
                    if (code != null) {
                        val r = rateOf(n)
                        if (r != null && r > 0) out[code] = r
                    }
                    n.keys().forEach { k -> walk(n.opt(k)) }
                }
            }
        }
        walk(root)
        return out.takeIf { it.isNotEmpty() }
    }

    private fun rateOf(o: JSONObject): Double? {
        var buy: Double? = null
        var sell: Double? = null
        var mid: Double? = null
        for (k in o.keys()) {
            val v = o.opt(k)
            val d = when (v) {
                is Number -> v.toDouble()
                is String -> v.replace(",", "").trim().toDoubleOrNull()
                else -> null
            } ?: continue
            val key = k.lowercase()
            if (key.contains("buy")) buy = d
            else if (key.contains("sell")) sell = d
            else if (key.contains("mid") || key.contains("weighted") || key == "rate") mid = d
        }
        if (mid != null) return mid
        return if (buy != null && sell != null) (buy + sell) / 2 else null
    }
}

object Categories {
    val all = listOf("Food", "Transport", "Airtime & Data", "Bills", "Shopping", "Health",
        "Education", "Transfers", "Cash", "Fees", "Salary", "Income", "Other")
}

object Stats {
    fun startOfDay(daysAgo: Int = 0): Long =
        LocalDate.now(ADDIS).minusDays(daysAgo.toLong()).atStartOfDay(ADDIS).toInstant().toEpochMilli()

    fun startOfMonth(): Long =
        LocalDate.now(ADDIS).withDayOfMonth(1).atStartOfDay(ADDIS).toInstant().toEpochMilli()

    fun startOfYear(): Long =
        LocalDate.now(ADDIS).withDayOfYear(1).atStartOfDay(ADDIS).toInstant().toEpochMilli()

    fun etb(d: Double): String = String.format(Locale.US, "%,.2f", d)

    /** Latest balance reported by each bank/wallet SMS. */
    fun latestBalances(list: List<Txn>): Map<String, Double> =
        list.filter { it.balance != null }.groupBy { it.bankId }
            .mapValues { e -> e.value.maxByOrNull { it.time }!!.balance!! }

    fun total(list: List<Txn>): Double = latestBalances(list).values.sum()
    fun spent(list: List<Txn>): Double = list.filter { !it.isIncome }.sumOf { it.amount }
    fun received(list: List<Txn>): Double = list.filter { it.isIncome }.sumOf { it.amount }

    fun byCategory(list: List<Txn>): List<Pair<String, Double>> =
        list.filter { !it.isIncome }.groupBy { it.category }
            .map { it.key to it.value.sumOf { t -> t.amount } }.sortedByDescending { it.second }

    fun byBank(list: List<Txn>): List<Pair<String, Double>> =
        list.filter { !it.isIncome }.groupBy { it.bankId }
            .map { it.key to it.value.sumOf { t -> t.amount } }.sortedByDescending { it.second }
}

object Summary {
    fun build(all: List<Txn>): Pair<String, String> {
        val yFrom = Stats.startOfDay(1)
        val yTo = Stats.startOfDay(0)
        val y = all.filter { it.time in yFrom until yTo }
        val t = all.filter { it.time >= yTo }
        val m = all.filter { it.time >= Stats.startOfMonth() }
        val top = Stats.byCategory(m).take(3).joinToString(", ") { "${it.first} ${Stats.etb(it.second)}" }
        val big = m.filter { !it.isIncome }.maxByOrNull { it.amount }
        val bal = Stats.total(all)
        val sb = StringBuilder()
        sb.appendLine("Yesterday: spent ETB ${Stats.etb(Stats.spent(y))} · received ETB ${Stats.etb(Stats.received(y))} (${y.size} transactions)")
        sb.appendLine("Today so far: spent ETB ${Stats.etb(Stats.spent(t))} · received ETB ${Stats.etb(Stats.received(t))}")
        sb.appendLine("This month: spent ETB ${Stats.etb(Stats.spent(m))} · received ETB ${Stats.etb(Stats.received(m))}")
        if (top.isNotEmpty()) sb.appendLine("Top spending: $top")
        if (big != null) sb.appendLine("Biggest expense: ETB ${Stats.etb(big.amount)} → ${big.counterparty.ifBlank { "unknown" }}")
        sb.append("Total balance: ETB ${Stats.etb(bal)}")
        val short = "Yesterday spent ETB ${Stats.etb(Stats.spent(y))}, received ETB ${Stats.etb(Stats.received(y))} · Balance ETB ${Stats.etb(bal)}"
        return short to sb.toString()
    }
}
