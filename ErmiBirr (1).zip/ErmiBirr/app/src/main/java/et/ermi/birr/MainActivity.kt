package et.ermi.birr

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class MainActivity : FragmentActivity() {
    private var canAuth by mutableStateOf(true)
    private var prompting = false
    private val vm: MainVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Hides balances from the recent-apps preview and blocks screenshots.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        Notifier.ensureChannels(this)
        Scheduler.scheduleAll(this)
        setContent { ErmiApp(vm, vm.unlocked, canAuth) { authenticate() } }
    }

    override fun onStart() {
        super.onStart()
        if (!vm.unlocked) authenticate()
    }

    /** Every time the app leaves the screen it locks again (but not on rotation). */
    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) vm.unlocked = false
    }

    private fun authenticate() {
        if (prompting) return
        val bm = BiometricManager.from(this)
        val weak = BiometricManager.Authenticators.BIOMETRIC_WEAK
        val cred = BiometricManager.Authenticators.DEVICE_CREDENTIAL
        // Best first: fingerprint/face OR phone PIN. Older Android versions cannot combine them,
        // so fall back to biometrics only, then to the phone PIN/pattern alone.
        val auth = listOf(weak or cred, weak, cred)
            .firstOrNull { bm.canAuthenticate(it) == BiometricManager.BIOMETRIC_SUCCESS }
        if (auth == null) { canAuth = false; return }
        canAuth = true
        prompting = true
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    prompting = false
                    vm.unlocked = true
                    vm.refresh()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    prompting = false
                }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Ermi Birr")
            .setSubtitle("Verify it's you with fingerprint, face or your phone password")
            .setAllowedAuthenticators(auth)
        // Without DEVICE_CREDENTIAL the prompt REQUIRES a cancel button, otherwise it crashes.
        if ((auth and cred) == 0) info.setNegativeButtonText("Cancel")
        try {
            prompt.authenticate(info.build())
        } catch (e: Exception) {
            prompting = false
        }
    }
}
