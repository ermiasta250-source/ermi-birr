package et.ermi.birr

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import java.time.Duration
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

object Notifier {
    fun ensureChannels(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("txn", "Transactions", NotificationManager.IMPORTANCE_HIGH))
            nm.createNotificationChannel(NotificationChannel("summary", "Daily summary", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private fun post(c: Context, id: Int, channel: String, title: String, text: String, big: String) {
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(c, channel)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(big))
            .setContentIntent(pi)
            .setAutoCancel(true)
        try { NotificationManagerCompat.from(c).notify(id, b.build()) } catch (_: SecurityException) { }
    }

    fun txn(c: Context, t: Txn, total: Double) {
        val bank = Banks.byId(t.bankId)
        val who = t.counterparty.ifBlank { "—" }
        val title = if (t.isIncome) "Money received · ETB ${Stats.etb(t.amount)}" else "Money spent · ETB ${Stats.etb(t.amount)}"
        val text = "${bank.short} · ${if (t.isIncome) "from" else "to"} $who"
        val big = buildString {
            appendLine("${bank.name}: ${if (t.isIncome) "received" else "spent"} ETB ${Stats.etb(t.amount)}")
            appendLine("${if (t.isIncome) "From" else "To"}: $who · ${t.category}")
            if (t.balance != null) appendLine("${bank.short} balance: ETB ${Stats.etb(t.balance)}")
            append("Total balance: ETB ${Stats.etb(total)}")
        }
        post(c, (t.id % 100000).toInt() + 1000, "txn", title, "$text · Balance ETB ${Stats.etb(total)}", big)
    }

    fun summary(c: Context, short: String, big: String) =
        post(c, 1, "summary", "Ermi Birr · Daily summary", short, big)
}

class SummaryWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        val db = AppDb.get(applicationContext)
        val all = db.dao().allNow()
        val (short, base) = Summary.build(all)
        val due = Ledger.dueLines(db.debts().openNow(), db.groups().allNow())
        val big = if (due.isEmpty()) base else base + "\n\nComing up:\n" + due.joinToString("\n")
        Notifier.summary(applicationContext, if (due.isEmpty()) short else short + " · " + due.size + " due soon", big)
        return Result.success()
    }
}

class RateWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        Rates.refresh(applicationContext)
        return Result.success()
    }
}

object Scheduler {
    fun scheduleAll(c: Context) {
        scheduleSummary(c)
        val req = PeriodicWorkRequestBuilder<RateWorker>(12, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("rates", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    /** Daily summary at the chosen Ethiopia local time (default 08:30 = 2:30 on the Ethiopian clock). */
    fun scheduleSummary(c: Context) {
        val now = ZonedDateTime.now(ADDIS)
        var next = now.withHour(Prefs.summaryHour(c)).withMinute(Prefs.summaryMin(c)).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val delay = Duration.between(now, next).toMillis()
        val req = PeriodicWorkRequestBuilder<SummaryWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("summary", ExistingPeriodicWorkPolicy.CANCEL_AND_REENQUEUE, req)
    }
}
