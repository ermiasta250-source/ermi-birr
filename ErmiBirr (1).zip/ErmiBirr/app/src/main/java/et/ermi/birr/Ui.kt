package et.ermi.birr

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.format.DateTimeFormatter

class MainVm(app: Application) : AndroidViewModel(app) {
    private val db = AppDb.get(app)
    private val dao = db.dao()
    val txns = dao.all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val debts = db.debts().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val groups = db.groups().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Lives in the ViewModel so rotating the phone does not lock the app again. */
    var unlocked by mutableStateOf(false)
    var rates by mutableStateOf(Rates.history(app))
    var busy by mutableStateOf(false)
    var toast by mutableStateOf<String?>(null)

    /** Re-reads SMS inbox + refreshes exchange rates. */
    fun refresh() {
        viewModelScope.launch {
            busy = true
            val c = getApplication<Application>()
            val n = SmsImporter.importInbox(c)
            val ok = Rates.refresh(c)
            rates = Rates.history(c)
            busy = false
            toast = when {
                n < 0 -> "Allow SMS access to read your bank messages"
                else -> "Updated · $n new transactions" + if (!ok) " · rates need internet" else ""
            }
        }
    }

    fun refreshRates() {
        viewModelScope.launch {
            busy = true
            val c = getApplication<Application>()
            val ok = Rates.refresh(c)
            rates = Rates.history(c)
            busy = false
            toast = if (ok) "Exchange rates updated" else "No internet — showing saved rates"
        }
    }

    fun addDebt(d: Debt) { viewModelScope.launch { db.debts().insert(d) } }
    fun settleDebt(id: Long, settled: Boolean) { viewModelScope.launch { db.debts().setSettled(id, settled) } }
    fun deleteDebt(id: Long) { viewModelScope.launch { db.debts().delete(id) } }
    fun addGroup(g: SavingGroup) { viewModelScope.launch { db.groups().insert(g) } }
    fun setPaidRounds(id: Long, n: Int) { viewModelScope.launch { db.groups().setPaid(id, n) } }
    fun deleteGroup(id: Long) { viewModelScope.launch { db.groups().delete(id) } }

    fun setCategory(id: Long, cat: String) { viewModelScope.launch { dao.setCategory(id, cat) } }
    fun clear() { viewModelScope.launch { dao.clear() } }
}

@Composable
fun ErmiApp(vm: MainVm, unlocked: Boolean, canAuth: Boolean, onUnlock: () -> Unit) {
    ErmiTheme {
        if (!unlocked) LockScreen(canAuth, onUnlock) else Main(vm)
    }
}

@Composable
fun LockScreen(canAuth: Boolean, onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().background(LogoBg).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painterResource(R.drawable.logo), null,
            Modifier.fillMaxWidth().aspectRatio(1000f / 545f), contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(24.dp))
        Text("Ermi Birr is locked", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(16.dp))
        if (canAuth) {
            Button(
                onClick = onUnlock,
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepGreen)
            ) {
                Icon(Icons.Filled.Fingerprint, null)
                Spacer(Modifier.width(8.dp))
                Text("Unlock")
            }
        } else {
            Text(
                "Set a fingerprint, face unlock or a screen-lock password/PIN in your phone Settings first, then try again.",
                color = Color.White, fontSize = 14.sp
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { ctx.startActivity(Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS)) },
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepGreen)
            ) { Text("Open security settings") }
            TextButton(onClick = onUnlock) { Text("Try again", color = Color.White) }
        }
    }
}

@Composable
fun Main(vm: MainVm) {
    var tab by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.toast) {
        vm.toast?.let { snack.showSnackbar(it); vm.toast = null }
    }
    BackHandler(showSettings) { showSettings = false }
    val items = listOf(
        "Home" to Icons.Filled.Home, "Txns" to Icons.Filled.Receipt,
        "Stats" to Icons.Filled.BarChart, "Scan" to Icons.Filled.QrCodeScanner,
        "Ledger" to Icons.Filled.AccountBalanceWallet, "Ermi AI" to Icons.Filled.SmartToy
    )
    Scaffold(
        containerColor = Bg,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i && !showSettings,
                        onClick = { tab = i; showSettings = false },
                        icon = { Icon(icon, label) },
                        label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                        alwaysShowLabel = true
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (showSettings) SettingsScreen(vm) { showSettings = false }
            else when (tab) {
                0 -> HomeScreen(vm) { showSettings = true }
                1 -> TxnScreen(vm)
                2 -> AnalyticsScreen(vm)
                3 -> ScanScreen()
                4 -> LedgerScreen(vm)
                else -> AssistantScreen(vm)
            }
        }
    }
}

// ---------- shared pieces ----------

@Composable
fun BankBadge(bank: Bank, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    // Drop a PNG named bank_<id>.png (e.g. bank_cbe.png) into res/drawable-nodpi to show the real logo.
    val res = remember(bank.id) { ctx.resources.getIdentifier("bank_${bank.id}", "drawable", ctx.packageName) }
    val shape = RoundedCornerShape((size.value * 0.28f).dp)
    Box(
        Modifier.size(size).clip(shape).background(if (res != 0) Color.White else Color(bank.color)),
        contentAlignment = Alignment.Center
    ) {
        if (res != 0) {
            Image(
                painterResource(res), bank.name,
                Modifier.fillMaxSize().padding((size.value * 0.08f).dp), contentScale = ContentScale.Fit
            )
        } else {
            Text(bank.short.take(3), color = Color.White, fontSize = (size.value * 0.3f).sp, fontWeight = FontWeight.Bold)
        }
    }
}

private val fmtDT = DateTimeFormatter.ofPattern("MMM d · h:mm a")

@Composable
fun TxnRow(t: Txn, onCategory: ((String) -> Unit)? = null) {
    val bank = Banks.byId(t.bankId)
    var menu by remember { mutableStateOf(false) }
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            BankBadge(bank, 42.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    t.counterparty.ifBlank { if (t.isIncome) "Money received" else "Payment" },
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${bank.short} · ${fmtDT.format(Instant.ofEpochMilli(t.time).atZone(ADDIS))}",
                    fontSize = 12.sp, color = Color.Gray
                )
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    (if (t.isIncome) "+" else "−") + "ETB " + Stats.etb(t.amount),
                    color = if (t.isIncome) Inc else Red, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Box {
                    Text(
                        t.category, fontSize = 11.sp, color = Green,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFFE6F2EC))
                            .clickable(enabled = onCategory != null) { menu = true }
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        Categories.all.forEach { c ->
                            DropdownMenuItem(text = { Text(c) }, onClick = { menu = false; onCategory?.invoke(c) })
                        }
                    }
                }
            }
        }
    }
}

private fun granted(c: Context, p: String) =
    ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

// ---------- Home ----------

@Composable
fun HomeScreen(vm: MainVm, openSettings: () -> Unit) {
    val ctx = LocalContext.current
    val txns by vm.txns.collectAsState()
    var hide by remember { mutableStateOf(Prefs.hide(ctx)) }
    val balances = Stats.latestBalances(txns)
    val month = txns.filter { it.time >= Stats.startOfMonth() }

    fun missing(): Boolean {
        val sms = !granted(ctx, Manifest.permission.READ_SMS) || !granted(ctx, Manifest.permission.RECEIVE_SMS)
        val notif = Build.VERSION.SDK_INT >= 33 && !granted(ctx, Manifest.permission.POST_NOTIFICATIONS)
        return sms || notif
    }
    var needPerm by remember { mutableStateOf(missing()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        needPerm = missing()
        vm.refresh()
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Row {
                        Text("Ermi ", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = DeepGreen)
                        Text("Birr", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Gold)
                    }
                    Text("Your financial overview · ${Eth.today()} E.C.", color = Color.Gray, fontSize = 13.sp)
                }
                IconButton(onClick = { vm.refresh() }) {
                    if (vm.busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Filled.Refresh, "Refresh")
                }
                IconButton(onClick = openSettings) { Icon(Icons.Filled.Settings, "Settings") }
            }
        }
        if (needPerm) item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF6DD)), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Allow access to start tracking", fontWeight = FontWeight.Bold)
                    Text(
                        "Ermi Birr reads only messages from your banks (on this phone, never uploaded) and sends you a notification for every transaction.",
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        val p = mutableListOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS)
                        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
                        launcher.launch(p.toTypedArray())
                    }) { Text("Allow messages & notifications") }
                }
            }
        }
        item {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(DeepGreen, Green))).padding(20.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("TOTAL BALANCE", color = Color(0xFFBFE3D2), fontSize = 12.sp, modifier = Modifier.weight(1f))
                        IconButton(onClick = { hide = !hide; Prefs.setHide(ctx, hide) }) {
                            Icon(if (hide) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null, tint = Color.White)
                        }
                    }
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("ETB ", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(
                            if (hide) "••••••" else Stats.etb(Stats.total(txns)),
                            color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "${balances.size} institutions · ${txns.size} transactions",
                        color = Color(0xFFBFE3D2), fontSize = 12.sp
                    )
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Received (month)", "+" + Stats.etb(Stats.received(month)), Inc, Icons.Filled.ArrowDownward, Modifier.weight(1f))
                StatCard("Spent (month)", "−" + Stats.etb(Stats.spent(month)), Red, Icons.Filled.ArrowUpward, Modifier.weight(1f))
            }
        }
        if (balances.isNotEmpty()) {
            item { Text("Accounts", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(balances.entries.sortedByDescending { it.value }.toList()) { e ->
                        val b = Banks.byId(e.key)
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(18.dp), modifier = Modifier.width(150.dp)
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                BankBadge(b, 40.dp)
                                Spacer(Modifier.height(8.dp))
                                Text(b.short, fontWeight = FontWeight.Bold)
                                Text(
                                    if (hide) "••••" else "ETB " + Stats.etb(e.value),
                                    fontSize = 13.sp, color = Green, fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
        item { Text("Recent activity", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        if (txns.isEmpty()) item {
            Text("No transactions yet. Allow SMS access, then tap the refresh button at the top.", color = Color.Gray)
        }
        items(txns.take(8), key = { it.id }) { t -> TxnRow(t) { c -> vm.setCategory(t.id, c) } }
    }
}

@Composable
fun StatCard(title: String, value: String, color: Color, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = color, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(title, fontSize = 12.sp, color = Color.Gray)
            }
            Text("$value ETB", color = color, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

// ---------- Transactions ----------

@Composable
fun TxnScreen(vm: MainVm) {
    val txns by vm.txns.collectAsState()
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) }
    val list = txns.filter {
        (filter == 0 || (filter == 1 && it.isIncome) || (filter == 2 && !it.isIncome)) &&
            (query.isBlank() || it.counterparty.contains(query, true) || it.category.contains(query, true) ||
                Banks.byId(it.bankId).name.contains(query, true))
    }
    val grouped = list.groupBy { Instant.ofEpochMilli(it.time).atZone(ADDIS).toLocalDate() }
    val dayFmt = remember { DateTimeFormatter.ofPattern("MMM d, yyyy") }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 12.dp)) {
            Text("Transactions", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(
                "${txns.size}", color = Green, fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFFDDF0E6)).padding(horizontal = 10.dp, vertical = 4.dp)
            )
            IconButton(onClick = { vm.refresh() }) {
                if (vm.busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                else Icon(Icons.Filled.Refresh, "Refresh", tint = Green)
            }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Search name, category or bank") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            listOf("All", "Income", "Expense").forEachIndexed { i, s ->
                FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(s) })
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            grouped.forEach { (day, rows) ->
                item(key = "h$day") { Text(dayFmt.format(day), color = Color.Gray, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp)) }
                items(rows, key = { it.id }) { t -> TxnRow(t) { c -> vm.setCategory(t.id, c) } }
            }
        }
    }
}

// ---------- Settings ----------

@Composable
fun SettingsScreen(vm: MainVm, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var sel by remember { mutableStateOf(Prefs.summaryHour(ctx) to Prefs.summaryMin(ctx)) }
    var confirm by remember { mutableStateOf(false) }
    val options = listOf(
        "8:30 AM  (2:30 on the Ethiopian clock)" to (8 to 30),
        "9:00 AM  (3:00 on the Ethiopian clock)" to (9 to 0),
        "2:30 PM" to (14 to 30),
        "8:30 PM  (2:30 evening, Ethiopian clock)" to (20 to 30),
        "9:00 PM" to (21 to 0)
    )
    fun open(i: Intent) = try { ctx.startActivity(i) } catch (_: Exception) { }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        SectionCard("Daily summary notification") {
            Text("Time is Ethiopia local time. Android may deliver it a few minutes late to save battery.", fontSize = 12.sp, color = Color.Gray)
            options.forEach { (label, hm) ->
                Row(Modifier.fillMaxWidth().clickable {
                    sel = hm; Prefs.setSummary(ctx, hm.first, hm.second); Scheduler.scheduleSummary(ctx)
                }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = sel == hm, onClick = {
                        sel = hm; Prefs.setSummary(ctx, hm.first, hm.second); Scheduler.scheduleSummary(ctx)
                    })
                    Text(label)
                }
            }
            OutlinedButton(onClick = {
                val (s, b) = Summary.build(vm.txns.value)
                Notifier.summary(ctx, s, b)
            }) { Text("Send a test summary now") }
        }
        SectionCard("Data") {
            Text("All data is stored on this phone only (local Room/SQLite database).", fontSize = 13.sp)
            Button(onClick = { vm.refresh() }) { Text("Re-scan all bank SMS now") }
            OutlinedButton(onClick = { confirm = true }) { Text("Delete all stored transactions", color = Red) }
        }
        SectionCard("Supported banks & wallets") {
            Banks.all.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    row.forEach { b ->
                        Column(Modifier.width(74.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            BankBadge(b, 44.dp)
                            Text(b.short, fontSize = 11.sp, maxLines = 1)
                        }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.width(74.dp)) }
                }
            }
        }
        SectionCard("About") {
            Text("Ermi Birr 1.0 — personal birr tracker", fontWeight = FontWeight.SemiBold)
            Text("Developed by Ermias Tadesse")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { open(Intent(Intent.ACTION_DIAL, Uri.parse("tel:0984193465"))) }) {
                    Icon(Icons.Filled.Phone, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Call")
                }
                OutlinedButton(onClick = { open(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/ermit01"))) }) { Text("Telegram") }
                OutlinedButton(onClick = { open(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:ermitech2023@gmail.com"))) }) {
                    Icon(Icons.Filled.Email, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Email")
                }
            }
            Text("0984193465 · @ermit01 · ermitech2023@gmail.com", fontSize = 12.sp, color = Color.Gray)
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Delete all transactions?") },
        text = { Text("This removes the data stored in Ermi Birr. Your SMS are not touched; re-scan will import them again.") },
        confirmButton = { TextButton(onClick = { vm.clear(); confirm = false }) { Text("Delete", color = Red) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
    )
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            content()
        }
    }
}
