package et.ermi.birr

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Telephony
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest

data class Parsed(
    val bank: Bank, val income: Boolean, val amount: Double, val balance: Double?,
    val counterparty: String, val ref: String?, val category: String
)

/** Reads only SMS that come from known Ethiopian bank / wallet sender IDs. Everything stays on the phone. */
object SmsParser {
    private val amountRx = Regex("""\b(?:ETB|Birr|Br\.?)\s*(\d[\d,]*(?:\.\d+)?)""", RegexOption.IGNORE_CASE)
    private val amountRx2 = Regex("""(\d[\d,]*(?:\.\d+)?)\s*(?:ETB|Birr)\b""", RegexOption.IGNORE_CASE)
    private val balRx = Regex("""balance\s*(?:is|:)?\s*(?:ETB|Birr)?\s*(\d[\d,]*(?:\.\d+)?)""", RegexOption.IGNORE_CASE)
    private val refRx = Regex(
        """(?:Ref(?:erence)?\s*(?:No\.?|Number)?|Transaction\s*(?:ID|number|no\.?)|receipt\s*no\.?)\s*(?:is\s*)?[:.\-]?\s*([A-Z0-9]{8,})""",
        RegexOption.IGNORE_CASE
    )
    private val whoRx = Regex(
        """\b(?:to|from)\s+([^.,\n]{2,60}?)(?=\s+(?:on|at|with|ref|your|via|using)\b|\s*\(|[.,\n]|$)""",
        RegexOption.IGNORE_CASE
    )
    private val incomeWords = listOf("credited", "received", "deposit", "cash in", "refund")
    private val expenseWords = listOf("debited", "transfer", "paid", "payment", "withdraw", "purchase",
        "sent", "bought", "airtime", "recharge", "charged")

    private fun num(s: String) = s.replace(",", "").toDoubleOrNull()

    fun parse(sender: String, body: String): Parsed? {
        val bank = Banks.match(sender) ?: return null
        val lower = body.lowercase()
        val inIdx = incomeWords.map { lower.indexOf(it) }.filter { it >= 0 }.minOrNull()
        val exIdx = expenseWords.map { lower.indexOf(it) }.filter { it >= 0 }.minOrNull()
        if (inIdx == null && exIdx == null) return null
        val income = when {
            inIdx == null -> false
            exIdx == null -> true
            else -> inIdx < exIdx
        }
        val m = amountRx.find(body) ?: amountRx2.find(body) ?: return null
        val amount = num(m.groupValues[1]) ?: return null
        if (amount <= 0) return null
        val balance = balRx.find(body)?.let { num(it.groupValues[1]) }
        val ref = refRx.find(body)?.groupValues?.get(1)
        val who = whoRx.find(body, m.range.last)?.groupValues?.get(1)?.trim().orEmpty()
        return Parsed(bank, income, amount, balance, who, ref, categorize(income, who, lower))
    }

    fun categorize(income: Boolean, who: String, body: String): String {
        val w = who.lowercase()
        fun has(s: String, p: String) = Regex("\\b(?:$p)", RegexOption.IGNORE_CASE).containsMatchIn(s)
        if (income) return if (has(body, "salary|payroll")) "Salary" else "Income"
        return when {
            has(w, "package|airtime|internet|data|recharge|ethio ?telecom|safaricom|bundle|voice") -> "Airtime & Data"
            has(w, "electric|ethiopian electric|eeu|water|utility|bill|dstv|tax|tv") -> "Bills"
            has(w, "fuel|taxi|ride|feres|zayride|bus|transport|parking|oil|nyala") -> "Transport"
            has(w, "restaurant|cafe|coffee|pizza|food|juice|bakery|kitchen|burger|lunch|dinner|hotel") -> "Food"
            has(w, "pharmacy|clinic|hospital|medical|health|drug") -> "Health"
            has(w, "school|college|university|tuition|academy") -> "Education"
            has(w, "supermarket|mall|shop|store|market|boutique|trading|plc") -> "Shopping"
            has(body, "withdraw|atm") -> "Cash"
            has(body, "service charge|fee|vat") && w.isBlank() -> "Fees"
            has(body, "transfer") -> "Transfers"
            else -> "Other"
        }
    }

    fun hash(bankId: String, body: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest("$bankId|${body.trim()}".toByteArray())
        return d.joinToString("") { "%02x".format(it) }.take(40)
    }
}

object SmsImporter {
    /** Returns the new Txn if it was not stored before. */
    suspend fun add(dao: TxnDao, sender: String, body: String, time: Long): Txn? {
        val p = SmsParser.parse(sender, body) ?: return null
        val t = Txn(
            hash = SmsParser.hash(p.bank.id, body), bankId = p.bank.id, isIncome = p.income,
            amount = p.amount, balance = p.balance, counterparty = p.counterparty, ref = p.ref,
            category = p.category, time = time, raw = body
        )
        val id = dao.insert(t)
        return if (id > 0) t.copy(id = id) else null
    }

    /** Scans the whole SMS inbox. Returns number of new transactions, or -1 when permission is missing. */
    suspend fun importInbox(c: Context): Int = withContext(Dispatchers.IO) {
        if (ContextCompat.checkSelfPermission(c, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED)
            return@withContext -1
        val dao = AppDb.get(c).dao()
        var n = 0
        c.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI, arrayOf("address", "body", "date"), null, null, "date DESC"
        )?.use { cur ->
            while (cur.moveToNext()) {
                val a = cur.getString(0) ?: continue
                val b = cur.getString(1) ?: continue
                if (add(dao, a, b, cur.getLong(2)) != null) n++
            }
        }
        n
    }
}

/** Fires the moment a bank SMS arrives: stores it and notifies you with the new balance. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val grouped = msgs.groupBy { it.originatingAddress ?: "" }
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                Notifier.ensureChannels(c)
                val dao = AppDb.get(c).dao()
                for ((addr, parts) in grouped) {
                    val body = parts.joinToString("") { it.messageBody ?: "" }
                    val t = SmsImporter.add(dao, addr, body, parts.first().timestampMillis)
                    if (t != null) Notifier.txn(c, t, Stats.total(dao.allNow()))
                }
            } finally {
                pending.finish()
            }
        }
    }
}
