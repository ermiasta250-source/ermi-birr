package et.ermi.birr

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import java.time.Instant
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

// ---------- Ethiopian calendar ----------

object Eth {
    private val months = listOf(
        "Meskerem", "Tikimt", "Hidar", "Tahsas", "Tir", "Yekatit", "Megabit",
        "Miazia", "Ginbot", "Sene", "Hamle", "Nehase", "Pagume"
    )

    /** Gregorian date -> Ethiopian (year, month 1..13, day). */
    fun parts(d: LocalDate): Triple<Int, Int, Int> {
        val jdn = d.toEpochDay() + 2440588L
        val t = jdn - 1723856L
        val cycle = t / 1461L
        val r = t % 1461L
        val n = r % 365L + 365L * (r / 1460L)
        val year = 4L * cycle + r / 365L - r / 1460L
        return Triple(year.toInt(), (n / 30L).toInt() + 1, (n % 30L).toInt() + 1)
    }

    fun format(d: LocalDate): String {
        val (y, m, day) = parts(d)
        return "${months[m - 1]} $day, $y"
    }

    fun today(): String = format(LocalDate.now(ADDIS))
}

// ---------- Debt ledger (who owes me / who I owe) ----------

@Entity(tableName = "debts")
data class Debt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val person: String,
    val amount: Double,
    val theyOweMe: Boolean,
    val note: String,
    val phone: String,
    val created: Long,
    val due: Long?,
    val settled: Boolean
)

@Dao
interface DebtDao {
    @Insert
    suspend fun insert(d: Debt): Long

    @Query("SELECT * FROM debts ORDER BY settled ASC, created DESC")
    fun all(): Flow<List<Debt>>

    @Query("SELECT * FROM debts WHERE settled = 0")
    suspend fun openNow(): List<Debt>

    @Query("UPDATE debts SET settled = :s WHERE id = :id")
    suspend fun setSettled(id: Long, s: Boolean)

    @Query("DELETE FROM debts WHERE id = :id")
    suspend fun delete(id: Long)
}

// ---------- Equb & Idir ----------

/** kind is "Equb" (rotating savings, fixed number of rounds) or "Idir" (ongoing dues). */
@Entity(tableName = "saving_groups")
data class SavingGroup(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,
    val name: String,
    val amount: Double,
    val members: Int,
    val myTurn: Int,
    val startDay: String,
    val periodDays: Int,
    val paidRounds: Int
)

@Dao
interface GroupDao {
    @Insert
    suspend fun insert(g: SavingGroup): Long

    @Query("SELECT * FROM saving_groups ORDER BY id DESC")
    fun all(): Flow<List<SavingGroup>>

    @Query("SELECT * FROM saving_groups")
    suspend fun allNow(): List<SavingGroup>

    @Query("UPDATE saving_groups SET paidRounds = :n WHERE id = :id")
    suspend fun setPaid(id: Long, n: Int)

    @Query("DELETE FROM saving_groups WHERE id = :id")
    suspend fun delete(id: Long)
}

object Ledger {
    private val shortFmt = DateTimeFormatter.ofPattern("MMM d", Locale.US)

    private fun start(g: SavingGroup): LocalDate =
        try { LocalDate.parse(g.startDay) } catch (e: Exception) { LocalDate.now(ADDIS) }

    /** Date of the next contribution I still have to pay, or null when an Equb is fully paid. */
    fun nextDue(g: SavingGroup): LocalDate? {
        if (g.kind == "Equb" && g.paidRounds >= g.members) return null
        return start(g).plusDays(g.paidRounds.toLong() * g.periodDays)
    }

    /** Date I receive the pot (Equb only). */
    fun payoutDate(g: SavingGroup): LocalDate? =
        if (g.kind == "Equb" && g.myTurn in 1..g.members) start(g).plusDays((g.myTurn - 1L) * g.periodDays) else null

    fun pot(g: SavingGroup): Double = g.amount * g.members

    fun daysUntil(d: LocalDate): Long = ChronoUnit.DAYS.between(LocalDate.now(ADDIS), d)

    fun rel(days: Long): String = when {
        days < 0 -> "${-days} days overdue"
        days == 0L -> "today"
        days == 1L -> "tomorrow"
        else -> "in $days days"
    }

    fun label(d: LocalDate): String = "${shortFmt.format(d)} · ${Eth.format(d)} E.C."

    fun dueDate(d: Debt): LocalDate? = d.due?.let { Instant.ofEpochMilli(it).atZone(ADDIS).toLocalDate() }

    /** Lines for the daily summary: things due in the next 3 days or already late. */
    fun dueLines(debts: List<Debt>, groups: List<SavingGroup>): List<String> {
        val out = mutableListOf<String>()
        debts.forEach { d ->
            if (d.settled) return@forEach
            val dd = dueDate(d) ?: return@forEach
            val n = daysUntil(dd)
            if (n <= 3) out += if (d.theyOweMe)
                "• ${d.person} owes you ETB ${Stats.etb(d.amount)} — due ${rel(n)}"
            else "• You owe ${d.person} ETB ${Stats.etb(d.amount)} — due ${rel(n)}"
        }
        groups.forEach { g ->
            val dd = nextDue(g)
            if (dd != null) {
                val n = daysUntil(dd)
                if (n <= 3) out += "• ${g.kind} ${g.name}: pay ETB ${Stats.etb(g.amount)} — ${rel(n)}"
            }
            val po = payoutDate(g)
            if (po != null) {
                val n = daysUntil(po)
                if (n in 0..3) out += "• ${g.kind} ${g.name}: your payout of ETB ${Stats.etb(pot(g))} is ${rel(n)}"
            }
        }
        return out
    }

    fun reminderText(d: Debt): String =
        "Selam ${d.person}, a friendly reminder about the ETB ${Stats.etb(d.amount)} you owe me" +
            (if (d.note.isNotBlank()) " (${d.note})" else "") + ". Thank you!"
}

// ---------- Screen ----------

@Composable
fun LedgerScreen(vm: MainVm) {
    val ctx = LocalContext.current
    val debts by vm.debts.collectAsState()
    val groups by vm.groups.collectAsState()
    var seg by remember { mutableIntStateOf(0) }
    var addDebt by remember { mutableStateOf(false) }
    var addGroup by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<(() -> Unit)?>(null) }
    fun open(i: Intent) = try { ctx.startActivity(i) } catch (_: Exception) { }

    val owedToMe = debts.filter { !it.settled && it.theyOweMe }.sumOf { it.amount }
    val iOwe = debts.filter { !it.settled && !it.theyOweMe }.sumOf { it.amount }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Column {
                Text("Ledger", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Debts, Equb and Idir — saved on this phone", color = Color.Gray, fontSize = 13.sp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = seg == 0, onClick = { seg = 0 }, label = { Text("Debts") })
                FilterChip(selected = seg == 1, onClick = { seg = 1 }, label = { Text("Equb & Idir") })
            }
        }
        if (seg == 0) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("They owe me", Stats.etb(owedToMe), Inc, Icons.Filled.ArrowDownward, Modifier.weight(1f))
                    StatCard("I owe", Stats.etb(iOwe), Red, Icons.Filled.ArrowUpward, Modifier.weight(1f))
                }
            }
            item {
                Button(onClick = { addDebt = true }) {
                    Icon(Icons.Filled.Add, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Add debt")
                }
            }
            if (debts.isEmpty()) item {
                Text("Nothing here yet. Add who owes you (shop credit, a friend) or who you owe.", color = Color.Gray)
            }
            items(debts, key = { it.id }) { d ->
                DebtCard(
                    d,
                    onSms = {
                        open(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + d.phone.trim()))
                            .putExtra("sms_body", Ledger.reminderText(d)))
                    },
                    onTelegram = {
                        open(Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://t.me/share/url?url=%20&text=" + Uri.encode(Ledger.reminderText(d)))))
                    },
                    onSettle = { vm.settleDebt(d.id, !d.settled) },
                    onDelete = { pendingDelete = { vm.deleteDebt(d.id) } }
                )
            }
        } else {
            item {
                Button(onClick = { addGroup = true }) {
                    Icon(Icons.Filled.Add, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Add Equb or Idir")
                }
            }
            if (groups.isEmpty()) item {
                Text("Track your Equb rounds (when to pay, when you receive the pot) and monthly Idir dues.", color = Color.Gray)
            }
            items(groups, key = { it.id }) { g ->
                GroupCard(
                    g,
                    onPaid = { vm.setPaidRounds(g.id, g.paidRounds + 1) },
                    onUndo = { vm.setPaidRounds(g.id, (g.paidRounds - 1).coerceAtLeast(0)) },
                    onDelete = { pendingDelete = { vm.deleteGroup(g.id) } }
                )
            }
        }
    }

    if (addDebt) AddDebtDialog(onDismiss = { addDebt = false }) { vm.addDebt(it); addDebt = false }
    if (addGroup) AddGroupDialog(onDismiss = { addGroup = false }) { vm.addGroup(it); addGroup = false }
    pendingDelete?.let { action ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete this entry?") },
            text = { Text("This cannot be undone.") },
            confirmButton = { TextButton(onClick = { action(); pendingDelete = null }) { Text("Delete", color = Red) } },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun DebtCard(d: Debt, onSms: () -> Unit, onTelegram: () -> Unit, onSettle: () -> Unit, onDelete: () -> Unit) {
    val dd = Ledger.dueDate(d)
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(d.person, fontWeight = FontWeight.Bold)
                    Text(
                        (if (d.theyOweMe) "Owes you" else "You owe") +
                            (if (d.settled) " · settled" else if (dd != null) " · due ${Ledger.label(dd)} (${Ledger.rel(Ledger.daysUntil(dd))})" else ""),
                        fontSize = 12.sp, color = Color.Gray
                    )
                    if (d.note.isNotBlank()) Text(d.note, fontSize = 12.sp)
                }
                Text(
                    "ETB " + Stats.etb(d.amount), fontWeight = FontWeight.Bold,
                    color = if (d.settled) Color.Gray else if (d.theyOweMe) Inc else Red
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                if (d.theyOweMe && !d.settled) {
                    TextButton(onClick = onSms) { Text("SMS") }
                    TextButton(onClick = onTelegram) { Text("Telegram") }
                }
                TextButton(onClick = onSettle) { Text(if (d.settled) "Reopen" else "Settled") }
                TextButton(onClick = onDelete) { Text("Delete", color = Red) }
            }
        }
    }
}

@Composable
private fun GroupCard(g: SavingGroup, onPaid: () -> Unit, onUndo: () -> Unit, onDelete: () -> Unit) {
    val next = Ledger.nextDue(g)
    val payout = Ledger.payoutDate(g)
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${g.kind} · ${g.name}", fontWeight = FontWeight.Bold)
                    Text(
                        "ETB ${Stats.etb(g.amount)} every ${if (g.periodDays == 7) "week" else if (g.periodDays == 14) "2 weeks" else if (g.periodDays == 30) "month" else "${g.periodDays} days"}",
                        fontSize = 12.sp, color = Color.Gray
                    )
                }
                if (g.kind == "Equb") Text("Pot ETB ${Stats.etb(Ledger.pot(g))}", fontWeight = FontWeight.SemiBold, color = Green, fontSize = 13.sp)
            }
            if (g.kind == "Equb" && g.members > 0) {
                Text("Paid ${g.paidRounds} of ${g.members} rounds", fontSize = 12.sp)
                LinearProgressIndicator(
                    progress = { (g.paidRounds.toFloat() / g.members).coerceIn(0f, 1f) },
                    color = Green, trackColor = Green.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth().height(8.dp)
                )
            } else {
                Text("Paid ${g.paidRounds} times", fontSize = 12.sp)
            }
            if (next != null) {
                val n = Ledger.daysUntil(next)
                Text(
                    "Next payment: ${Ledger.label(next)} (${Ledger.rel(n)})",
                    fontSize = 13.sp, fontWeight = FontWeight.Medium, color = if (n < 0) Red else Color(0xFF14201B)
                )
            } else {
                Text("All rounds paid ✓", fontSize = 13.sp, color = Inc)
            }
            if (payout != null) {
                Text("You receive the pot: ${Ledger.label(payout)} (${Ledger.rel(Ledger.daysUntil(payout))})", fontSize = 12.sp, color = Color.Gray)
            }
            Row {
                TextButton(onClick = onPaid, enabled = next != null) { Text("Mark paid") }
                TextButton(onClick = onUndo, enabled = g.paidRounds > 0) { Text("Undo") }
                TextButton(onClick = onDelete) { Text("Delete", color = Red) }
            }
        }
    }
}

@Composable
private fun AddDebtDialog(onDismiss: () -> Unit, onSave: (Debt) -> Unit) {
    var theyOweMe by remember { mutableStateOf(true) }
    var person by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var days by remember { mutableStateOf("") }
    val amt = amount.toDoubleOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add debt") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = theyOweMe, onClick = { theyOweMe = true }, label = { Text("They owe me") })
                    FilterChip(selected = !theyOweMe, onClick = { theyOweMe = false }, label = { Text("I owe") })
                }
                OutlinedTextField(person, { person = it.take(60) }, label = { Text("Person") }, singleLine = true)
                OutlinedTextField(
                    amount, { amount = it.filter { c -> c.isDigit() || c == '.' }.take(12) },
                    label = { Text("Amount (ETB)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                OutlinedTextField(
                    phone, { phone = it.filter { c -> c.isDigit() || c == '+' }.take(16) },
                    label = { Text("Phone (for reminders)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                )
                OutlinedTextField(note, { note = it.take(80) }, label = { Text("Note (optional)") }, singleLine = true)
                OutlinedTextField(
                    days, { days = it.filter { c -> c.isDigit() }.take(4) },
                    label = { Text("Due in how many days? (optional)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = person.isNotBlank() && amt != null && amt > 0,
                onClick = {
                    val due = days.toLongOrNull()?.let {
                        LocalDate.now(ADDIS).plusDays(it).atStartOfDay(ADDIS).toInstant().toEpochMilli()
                    }
                    onSave(
                        Debt(
                            person = person.trim(), amount = amt ?: 0.0, theyOweMe = theyOweMe, note = note.trim(),
                            phone = phone, created = System.currentTimeMillis(), due = due, settled = false
                        )
                    )
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun AddGroupDialog(onDismiss: () -> Unit, onSave: (SavingGroup) -> Unit) {
    var kind by remember { mutableStateOf("Equb") }
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var members by remember { mutableStateOf("") }
    var turn by remember { mutableStateOf("") }
    var period by remember { mutableIntStateOf(30) }
    var startText by remember { mutableStateOf(LocalDate.now(ADDIS).toString()) }
    var paid by remember { mutableStateOf("0") }
    val amt = amount.toDoubleOrNull()
    val mem = members.toIntOrNull()
    val myTurn = turn.toIntOrNull()
    val start = try { LocalDate.parse(startText) } catch (e: Exception) { null }
    val equb = kind == "Equb"
    val valid = name.isNotBlank() && amt != null && amt > 0 && start != null &&
        (!equb || (mem != null && mem >= 2 && myTurn != null && myTurn in 1..mem))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Equb or Idir") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = equb, onClick = { kind = "Equb" }, label = { Text("Equb") })
                    FilterChip(selected = !equb, onClick = { kind = "Idir" }, label = { Text("Idir") })
                }
                OutlinedTextField(name, { name = it.take(40) }, label = { Text("Name (e.g. Office Equb)") }, singleLine = true)
                OutlinedTextField(
                    amount, { amount = it.filter { c -> c.isDigit() || c == '.' }.take(12) },
                    label = { Text(if (equb) "My contribution per round (ETB)" else "Dues per period (ETB)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                if (equb) {
                    OutlinedTextField(
                        members, { members = it.filter { c -> c.isDigit() }.take(3) },
                        label = { Text("Members (= number of rounds)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    OutlinedTextField(
                        turn, { turn = it.filter { c -> c.isDigit() }.take(3) },
                        label = { Text("My turn to receive (round number)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
                Text("How often?", fontSize = 12.sp, color = Color.Gray)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = period == 7, onClick = { period = 7 }, label = { Text("Weekly") })
                    FilterChip(selected = period == 14, onClick = { period = 14 }, label = { Text("2 weeks") })
                    FilterChip(selected = period == 30, onClick = { period = 30 }, label = { Text("Monthly") })
                }
                OutlinedTextField(
                    startText, { startText = it.take(10) },
                    label = { Text("First round date (YYYY-MM-DD)") }, singleLine = true,
                    isError = start == null,
                    supportingText = { if (start != null) Text(Eth.format(start) + " E.C.") }
                )
                OutlinedTextField(
                    paid, { paid = it.filter { c -> c.isDigit() }.take(3) },
                    label = { Text("Rounds already paid") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = {
                    onSave(
                        SavingGroup(
                            kind = kind, name = name.trim(), amount = amt ?: 0.0,
                            members = if (equb) (mem ?: 0) else 0, myTurn = if (equb) (myTurn ?: 0) else 0,
                            startDay = (start ?: LocalDate.now(ADDIS)).toString(), periodDays = period,
                            paidRounds = paid.toIntOrNull() ?: 0
                        )
                    )
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
