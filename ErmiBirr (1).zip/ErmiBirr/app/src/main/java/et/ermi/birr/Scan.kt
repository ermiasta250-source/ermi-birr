package et.ermi.birr

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage

private val trusted = listOf(
    "verify.et", "cbe.com.et", "combanketh.et", "ethiotelecom.et", "telebirr.com",
    "bankofabyssinia.com", "awashbank.com", "dashenbanksc.com", "zemenbank.com",
    "hibretbank.com.et", "chapa.co"
)

private fun isTrusted(s: String): Boolean {
    if (!s.startsWith("https://")) return false
    val host = try { Uri.parse(s).host?.lowercase() } catch (_: Exception) { null } ?: return false
    return trusted.any { host == it || host.endsWith(".$it") }
}

@Composable
fun ScanScreen() {
    val ctx = LocalContext.current
    var camOk by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { camOk = it }
    var result by remember { mutableStateOf<String?>(null) }
    fun open(url: String) = try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Scan receipt QR", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Scan the QR code on a bank or Telebirr receipt to check it on the official verification page.", color = Color.Gray, fontSize = 13.sp)

        val r = result
        if (r == null) {
            if (camOk) {
                CameraBox { result = it }
            } else {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Camera permission is needed to scan QR codes.")
                        Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Allow camera") }
                    }
                }
            }
        } else {
            val ok = isTrusted(r)
            Card(
                colors = CardDefaults.cardColors(containerColor = if (ok) Color(0xFFE6F6EC) else Color(0xFFFFEFEF)),
                shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row {
                        Icon(if (ok) Icons.Filled.CheckCircle else Icons.Filled.Warning, null, tint = if (ok) Inc else Red)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (ok) "Official verification link" else "Not an official verification site — be careful, this receipt may be fake.",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Text(r, fontSize = 12.sp)
                    if (r.startsWith("http")) Button(onClick = { open(r) }) { Text("Open verification page") }
                    OutlinedButton(onClick = { result = null }) { Text("Scan again") }
                }
            }
        }

        SectionCard("Verify manually") {
            Button(onClick = { open("https://verify.et/verify/cbe") }) { Text("Open verify.et (CBE)") }
            Text(
                "Always compare the amount, sender and date shown on the official page with the receipt you were given.",
                fontSize = 12.sp, color = Color.Gray
            )
        }
    }
}

@OptIn(ExperimentalGetImage::class)
@Composable
fun CameraBox(onResult: (String) -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scanner = remember {
        BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())
    }
    var done by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        onDispose {
            try { ProcessCameraProvider.getInstance(ctx).get().unbindAll() } catch (_: Exception) { }
            scanner.close()
        }
    }
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(340.dp).clip(RoundedCornerShape(24.dp)),
        factory = { c ->
            val pv = PreviewView(c)
            val fut = ProcessCameraProvider.getInstance(c)
            fut.addListener({
                val provider = fut.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(ContextCompat.getMainExecutor(c)) { proxy ->
                    val img = proxy.image
                    if (img == null || done) { proxy.close(); return@setAnalyzer }
                    val input = InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees)
                    scanner.process(input)
                        .addOnSuccessListener { list ->
                            val v = list.firstOrNull()?.rawValue
                            if (v != null && !done) { done = true; onResult(v) }
                        }
                        .addOnCompleteListener { proxy.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            }, ContextCompat.getMainExecutor(c))
            pv
        }
    )
}
