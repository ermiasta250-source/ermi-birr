package et.ermi.birr

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale

@Composable
fun AnalyticsScreen(vm: MainVm) {
    val txns by vm.txns.collectAsState()
    var period by remember { mutableIntStateOf(1) }
    val from = when (period) {
        0 -> Stats.startOfDay(6)
        1 -> Stats.startOfMonth()
        else -> Stats.startOfYear()
    }
    val list = txns.filter { it.time >= from }
    val spent = Stats.spent(list)
    val received = Stats.received(list)

    val today = LocalDate.now(ADDIS)
    val buckets: List<Double>
    val labels: Pair<String, String>
    if (period == 2) {
        buckets = (1..today.monthValue).map { m ->
            list.filter { !it.isIncome && Instant.ofEpochMilli(it.time).atZone(ADDIS).monthValue == m }.sumOf { it.amount }
        }
        labels = "Jan" to java.time.Month.of(today.monthValue).name.take(3).lowercase().replaceFirstChar { it.uppercase() }
    } else {
        val start = Instant.ofEpochMilli(from).atZone(ADDIS).toLocalDate()
        val days = ChronoUnit.DAYS.between(start, today).toInt() + 1
        buckets = (0 until days).map { d ->
            val ds = start.plusDays(d.toLong()).atStartOfDay(ADDIS).toInstant().toEpochMilli()
            val de = ds + 86_400_000L
            list.filter { !it.isIncome && it.time in ds until de }.sumOf { it.amount }
        }
        labels = start.toString().takeLast(5) to today.toString().takeLast(5)
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column {
                Text("Analytics", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Financial insights & trends", color = Color.Gray, fontSize = 13.sp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Week", "Month", "Year").forEachIndexed { i, s ->
                    FilterChip(selected = period == i, onClick = { period = i }, label = { Text(s) })
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Received", "+" + Stats.etb(received), Inc, Icons.Filled.ArrowDownward, Modifier.weight(1f))
                StatCard("Spent", "−" + Stats.etb(spent), Red, Icons.Filled.ArrowUpward, Modifier.weight(1f))
            }
        }
        item {
            val net = received - spent
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Net for the period", color = Color.Gray, fontSize = 12.sp)
                    Text((if (net >= 0) "+" else "−") + "ETB " + Stats.etb(kotlin.math.abs(net)), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = if (net >= 0) Inc else Red)
                    if (received > 0) Text("Savings rate: ${((received - spent) / received * 100).toInt()}%", fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
        item {
            SectionCard(if (period == 2) "Spending by month" else "Daily spending") {
                BarChart(buckets, labels)
            }
        }
        item {
            SectionCard("Top spending categories") {
                val cats = Stats.byCategory(list)
                if (cats.isEmpty()) Text("No spending in this period.", color = Color.Gray)
                cats.take(6).forEach { (n, v) -> BarRow(n, v, spent, Red) }
            }
        }
        item {
            SectionCard("Spending by bank") {
                val banks = Stats.byBank(list)
                if (banks.isEmpty()) Text("No spending in this period.", color = Color.Gray)
                banks.forEach { (id, v) ->
                    val b = Banks.byId(id)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BankBadge(b, 28.dp)
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.weight(1f)) { BarRow(b.short, v, spent, Color(b.color)) }
                    }
                }
            }
        }
        item { RatesCard(vm) }
    }
}

@Composable
fun BarRow(label: String, value: Double, total: Double, color: Color) {
    val frac = if (total > 0) (value / total).toFloat().coerceIn(0f, 1f) else 0f
    Column {
        Row {
            Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Text("ETB ${Stats.etb(value)}  ${(frac * 100).toInt()}%", fontSize = 12.sp, color = Color.Gray)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { frac }, color = color, trackColor = color.copy(alpha = 0.15f),
            modifier = Modifier.fillMaxWidth().height(8.dp)
        )
    }
}

@Composable
fun BarChart(values: List<Double>, labels: Pair<String, String>) {
    val max = (values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    Canvas(Modifier.fillMaxWidth().height(120.dp)) {
        val n = values.size.coerceAtLeast(1)
        val gap = 3.dp.toPx()
        val w = ((size.width - gap * (n - 1)) / n).coerceAtLeast(1f)
        values.forEachIndexed { i, v ->
            val h = ((v / max).toFloat() * size.height).coerceAtLeast(2f)
            drawRoundRect(
                Red.copy(alpha = 0.85f), topLeft = Offset(i * (w + gap), size.height - h),
                size = Size(w, h), cornerRadius = CornerRadius(3.dp.toPx())
            )
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(labels.first, fontSize = 11.sp, color = Color.Gray)
        Text("max ETB ${Stats.etb(max)}", fontSize = 11.sp, color = Color.Gray)
        Text(labels.second, fontSize = 11.sp, color = Color.Gray)
    }
}

@Composable
fun LineChart(values: List<Double>) {
    val lo = values.min()
    val hi = values.max()
    val span = (hi - lo).takeIf { it > 0 } ?: 1.0
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        val stepX = if (values.size > 1) size.width / (values.size - 1) else 0f
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = i * stepX
            val y = size.height - ((v - lo) / span).toFloat() * (size.height - 12.dp.toPx()) - 6.dp.toPx()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            drawCircle(Green, 3.dp.toPx(), Offset(x, y))
        }
        drawPath(path, Green, style = Stroke(2.5.dp.toPx()))
    }
}

fun rateSourceLabel(d: DayRates): String =
    if (d.source == "NBE") "National Bank of Ethiopia · " + (if (d.published.isNotBlank()) d.published else d.day)
    else "Market rate (NBE not reachable) · ${d.day}"

@Composable
fun RatesCard(vm: MainVm) {
    val hist = vm.rates
    var amt by remember { mutableStateOf("1") }
    val a = amt.toDoubleOrNull() ?: 0.0
    SectionCard("Exchange rates (ETB)") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (hist.isEmpty()) "No rates saved yet" else rateSourceLabel(hist.last()) + " · updates itself every day when you have internet",
                fontSize = 12.sp, color = Color.Gray, modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { vm.refreshRates() }) {
                if (vm.busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                else Icon(Icons.Filled.Refresh, "Refresh rates", tint = Green)
            }
        }
        OutlinedTextField(
            value = amt, onValueChange = { amt = it.filter { c -> c.isDigit() || c == '.' }.take(12) },
            label = { Text("Amount in foreign currency") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        if (hist.isNotEmpty()) {
            val today = hist.last()
            val prev = hist.getOrNull(hist.size - 2)
            Rates.codes.forEach { code ->
                val r = today.etbPer[code] ?: return@forEach
                val ch = prev?.etbPer?.get(code)?.let { r / it - 1 }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(code, fontWeight = FontWeight.Bold, modifier = Modifier.width(52.dp))
                    Text("1 = ETB ${String.format(Locale.US, "%.2f", r)}", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.weight(1f))
                    if (ch != null) Text(
                        String.format(Locale.US, "%+.2f%%", ch * 100), fontSize = 12.sp,
                        color = if (ch >= 0) Inc else Red, modifier = Modifier.padding(end = 10.dp)
                    )
                    Text("ETB ${Stats.etb(a * r)}", fontWeight = FontWeight.SemiBold)
                }
            }
            val usd = hist.mapNotNull { it.etbPer["USD"] }
            Spacer(Modifier.height(4.dp))
            Text("USD → ETB, day by day", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            if (usd.size >= 2) LineChart(usd)
            else Text("The daily chart builds up automatically: one point is saved each day you open the app or have internet.", fontSize = 12.sp, color = Color.Gray)
        }
        Text(
            "NBE indicative rate = weighted average of the banks' transactions of the previous day. It is a reference rate; banks and the parallel market buy/sell at slightly different prices.",
            fontSize = 11.sp, color = Color.Gray
        )
    }
}
