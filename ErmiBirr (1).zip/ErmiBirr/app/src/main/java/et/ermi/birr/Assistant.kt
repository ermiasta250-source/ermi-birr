package et.ermi.birr

import java.time.Instant
import java.time.LocalDate

/**
 * Ermi — the built-in finance assistant. Runs fully offline on your own transactions
 * (no API key, no data leaves the phone).
 */
object Assistant {
    private fun etb(d: Double) = "ETB ${Stats.etb(d)}"

    private fun period(q: String): Pair<String, Long> = when {
        q.contains("today") -> "today" to Stats.startOfDay(0)
        q.contains("yesterday") -> "since yesterday" to Stats.startOfDay(1)
        q.contains("week") -> "the last 7 days" to Stats.startOfDay(6)
        q.contains("year") -> "this year" to Stats.startOfYear()
        q.contains("all time") || Regex("""\bever\b""").containsMatchIn(q) -> "all time" to 0L
        else -> "this month" to Stats.startOfMonth()
    }

    fun answer(raw: String, all: List<Txn>, rates: List<DayRates>): String {
        val q = raw.lowercase().trim()
        fun has(vararg k: String) = k.any { q.contains(it) }
        fun hasWord(vararg k: String) = k.any { Regex("""\b${Regex.escape(it)}\b""").containsMatchIn(q) }
        if (hasWord("rate", "rates", "usd", "eur", "gbp", "sar", "aed", "cny") ||
            has("dollar", "euro", "pound", "riyal", "dirham", "yuan", "exchange", "ዶላር"))
            return rateAnswer(q, rates)
        if (all.isEmpty())
            return "I don't see any transactions yet. Go to Home, allow SMS access and tap the refresh button, then ask me again."
        val (label, from) = period(q)
        val list = all.filter { it.time >= from }
        return when {
            has("balance", "how much do i have", "remaining", "ቀሪ", "ሂሳብ") && !has("spend", "spent") -> balance(all)
            has("biggest", "largest", "highest", "most expensive") -> biggest(list, label)
            has("bank", "wallet") && has("spend", "spent", "most", "use") -> byBank(list, label)
            has("category", "categories", "where", "breakdown", "what did i") -> categories(list, label)
            has("income", "received", "earn", "salary", "deposit", "ገቢ") && !has("spend") -> income(list, label)
            has("spend", "spent", "expense", "outflow", "paid", "ወጪ") -> spend(list, label)
            has("forecast", "run out", "last me", "days left") ||
                (has("last", "enough") && !has("week", "month", "year", "time")) -> forecast(all)
            has("save", "saving", "budget", "advice", "reduce", "problem", "improve", "wasting") ||
                hasWord("cut", "tip", "tips", "help") -> advice(all)
            (hasWord("hello", "hi", "selam") || has("ሰላም")) && q.length < 14 ->
                "Selam! I'm Ermi. Ask me about your balance, spending, income, biggest expenses, exchange rates, or how to save more."
            else -> "I can answer things like:\n• What is my balance?\n• How much did I spend this week?\n• Where does my money go?\n• What was my biggest expense?\n• Which bank do I use most?\n• Will my money last?\n• How can I save more?\n• 100 USD in birr?"
        }
    }

    private fun balance(all: List<Txn>): String {
        val b = Stats.latestBalances(all)
        if (b.isEmpty()) return "No balance information found in your messages yet."
        val lines = b.entries.sortedByDescending { it.value }.joinToString("\n") { "• ${Banks.byId(it.key).name}: ${etb(it.value)}" }
        return "Your total balance is ${etb(b.values.sum())}.\n$lines"
    }

    private fun spend(list: List<Txn>, label: String): String {
        val ex = list.filter { !it.isIncome }
        if (ex.isEmpty()) return "No spending found for $label."
        val top = Stats.byCategory(list).take(3).joinToString(", ") { "${it.first} ${etb(it.second)}" }
        return "For $label you spent ${etb(Stats.spent(list))} in ${ex.size} payments. Top: $top."
    }

    private fun income(list: List<Txn>, label: String): String {
        val inc = list.filter { it.isIncome }
        if (inc.isEmpty()) return "No money received for $label."
        val big = inc.maxByOrNull { it.amount }!!
        return "For $label you received ${etb(Stats.received(list))} in ${inc.size} deposits. Largest: ${etb(big.amount)} from ${big.counterparty.ifBlank { "unknown" }}."
    }

    private fun biggest(list: List<Txn>, label: String): String {
        val t = list.filter { !it.isIncome }.sortedByDescending { it.amount }.take(3)
        if (t.isEmpty()) return "No expenses found for $label."
        return "Biggest expenses for $label:\n" + t.joinToString("\n") {
            "• ${etb(it.amount)} → ${it.counterparty.ifBlank { Banks.byId(it.bankId).name }} (${Instant.ofEpochMilli(it.time).atZone(ADDIS).toLocalDate()})"
        }
    }

    private fun byBank(list: List<Txn>, label: String): String {
        val b = Stats.byBank(list)
        if (b.isEmpty()) return "No spending found for $label."
        val total = b.sumOf { it.second }
        return "Spending by bank for $label:\n" + b.joinToString("\n") {
            "• ${Banks.byId(it.first).name}: ${etb(it.second)} (${(it.second / total * 100).toInt()}%)"
        }
    }

    private fun categories(list: List<Txn>, label: String): String {
        val c = Stats.byCategory(list)
        if (c.isEmpty()) return "No spending found for $label."
        val total = c.sumOf { it.second }
        return "Where your money went for $label:\n" + c.take(6).joinToString("\n") {
            "• ${it.first}: ${etb(it.second)} (${(it.second / total * 100).toInt()}%)"
        }
    }

    private fun forecast(all: List<Txn>): String {
        val bal = Stats.total(all)
        val from = Stats.startOfDay(29)
        val recent = all.filter { it.time >= from && !it.isIncome }
        if (recent.isEmpty()) return "Not enough spending history yet for a forecast."
        val firstDay = Instant.ofEpochMilli(all.minOf { it.time }).atZone(ADDIS).toLocalDate()
        val days = maxOf(1L, minOf(30L, java.time.temporal.ChronoUnit.DAYS.between(firstDay, LocalDate.now(ADDIS)) + 1))
        val perDay = recent.sumOf { it.amount } / days
        if (perDay <= 0.0) return "You are barely spending — nothing to forecast."
        val left = bal / perDay
        return "You spend about ${etb(perDay)} per day. With a balance of ${etb(bal)} that lasts roughly ${left.toInt()} days if nothing new comes in."
    }

    private fun advice(all: List<Txn>): String {
        val m = all.filter { it.time >= Stats.startOfMonth() }
        if (m.isEmpty()) return "Add or import more transactions this month and I will give you tips."
        val spent = Stats.spent(m)
        val rec = Stats.received(m)
        val tips = mutableListOf<String>()
        if (rec > 0) {
            val rate = (rec - spent) / rec * 100
            tips += if (rate < 0) "You spent ${etb(spent - rec)} more than you received this month — pause non-essential spending."
            else "You kept ${rate.toInt()}% of what you received this month. A 20% target is a good habit."
        }
        val cats = Stats.byCategory(m)
        cats.firstOrNull()?.let { if (spent > 0 && it.second / spent > 0.5) tips += "${it.first} is ${(it.second / spent * 100).toInt()}% of your spending. Try setting a limit for it." }
        val repeats = m.filter { !it.isIncome && it.counterparty.isNotBlank() }
            .groupBy { it.counterparty }.filter { it.value.size >= 5 }.maxByOrNull { it.value.size }
        repeats?.let { tips += "You paid '${it.key}' ${it.value.size} times (${etb(it.value.sumOf { t -> t.amount })}). One larger bundle or plan may be cheaper." }
        val uncategorized = m.count { !it.isIncome && it.category == "Other" }
        if (uncategorized > 5) tips += "$uncategorized payments are in 'Other'. Tap their category in Transactions to sort them for better insight."
        tips += "Move money to savings right after you get paid, before you spend."
        return "Here is what I see this month:\n" + tips.joinToString("\n") { "• $it" }
    }

    private fun rateAnswer(q: String, rates: List<DayRates>): String {
        val t = rates.lastOrNull() ?: return "No exchange rates saved yet. Connect to the internet and tap refresh in Analytics."
        val code = when {
            q.contains("eur") || q.contains("euro") -> "EUR"
            q.contains("gbp") || q.contains("pound") -> "GBP"
            q.contains("sar") || q.contains("riyal") -> "SAR"
            q.contains("aed") || q.contains("dirham") -> "AED"
            q.contains("cny") || q.contains("yuan") -> "CNY"
            else -> "USD"
        }
        val n = Regex("""\d+(?:\.\d+)?""").find(q)?.value?.toDoubleOrNull() ?: 1.0
        val r = t.etbPer[code] ?: return "No rate for $code yet."
        val nTxt = if (n % 1.0 == 0.0) n.toLong().toString() else n.toString()
        return "$nTxt $code ≈ ${etb(n * r)} (${rateSourceLabel(t)}; banks buy/sell slightly differently)."
    }
}
