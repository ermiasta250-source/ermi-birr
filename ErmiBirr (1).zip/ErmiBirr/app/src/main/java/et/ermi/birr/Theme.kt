package et.ermi.birr

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val LogoBg = Color(0xFF05423A)
val DeepGreen = Color(0xFF06403A)
val Green = Color(0xFF0B6B45)
val Gold = Color(0xFFC9A24B)
val Bg = Color(0xFFF6F8F7)
val Red = Color(0xFFD64545)
val Inc = Color(0xFF14975A)

@Composable
fun ErmiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green, onPrimary = Color.White, secondary = Gold,
            background = Bg, surface = Color.White, onSurface = Color(0xFF14201B),
            surfaceVariant = Color(0xFFEAF0ED)
        ),
        content = content
    )
}
