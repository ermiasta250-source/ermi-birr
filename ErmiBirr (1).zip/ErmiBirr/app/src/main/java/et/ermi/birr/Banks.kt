package et.ermi.birr

data class Bank(
    val id: String,
    val name: String,
    val short: String,
    val color: Long,
    /** SMS sender IDs (upper-case, letters/digits only). Edit here if your bank uses another sender name. */
    val aliases: List<String>
)

object Banks {
    // Order matters: more specific senders first (CBEBirr before CBE).
    val all = listOf(
        Bank("cbebirr", "CBE Birr", "CBEBirr", 0xFF5B1F63, listOf("CBEBIRR")),
        Bank("cbe", "Commercial Bank of Ethiopia", "CBE", 0xFF7A2A7E, listOf("CBE")),
        Bank("telebirr", "Telebirr", "TEL", 0xFF0A8FDC, listOf("TELEBIRR", "127")),
        Bank("ethiotelecom", "Ethio Telecom", "ETH", 0xFF4CAF50, listOf("ETHIOTELECOM", "ETHIOTEL", "994")),
        Bank("mpesa", "M-PESA Ethiopia", "MPS", 0xFF43A047, listOf("MPESA")),
        Bank("amole", "Amole (Dashen)", "AMO", 0xFF0B4F9E, listOf("AMOLE")),
        Bank("chapa", "Chapa", "CHP", 0xFF7DC242, listOf("CHAPA")),
        Bank("boa", "Bank of Abyssinia", "BOA", 0xFFE69A0B, listOf("BOA", "ABYSSINIA")),
        Bank("awash", "Awash Bank", "AWA", 0xFFF47C20, listOf("AWASH", "AWB")),
        Bank("dashen", "Dashen Bank", "DAS", 0xFF0B3C8C, listOf("DASHEN")),
        Bank("wegagen", "Wegagen Bank", "WEG", 0xFFE65100, listOf("WEGAGEN")),
        Bank("zemen", "Zemen Bank", "ZEM", 0xFF6A1B9A, listOf("ZEMEN")),
        Bank("nib", "Nib International Bank", "NIB", 0xFFC62828, listOf("NIB")),
        Bank("hibret", "Hibret Bank", "HIB", 0xFF00796B, listOf("HIBRET", "UNITEDBANK")),
        Bank("coop", "Cooperative Bank of Oromia", "COOP", 0xFF0097D6, listOf("COOP", "COOPBANK", "CBO")),
        Bank("enat", "Enat Bank", "ENA", 0xFFEF6C00, listOf("ENAT")),
        Bank("bunna", "Bunna Bank", "BUN", 0xFF6D4C41, listOf("BUNNA")),
        Bank("berhan", "Berhan Bank", "BER", 0xFF2E7D32, listOf("BERHAN")),
        Bank("oromia", "Oromia Bank", "OIB", 0xFF1B5E20, listOf("OROMIA", "OIB")),
        Bank("lion", "Lion International Bank", "LIB", 0xFFF9A825, listOf("LION", "LIB")),
        Bank("abay", "Abay Bank", "ABY", 0xFF1565C0, listOf("ABAY")),
        Bank("amhara", "Amhara Bank", "AMH", 0xFF00838F, listOf("AMHARA")),
        Bank("siinqee", "Siinqee Bank", "SIQ", 0xFF8E24AA, listOf("SIINQEE")),
        Bank("global", "Global Bank Ethiopia", "GLB", 0xFF37474F, listOf("GLOBAL")),
        Bank("zamzam", "ZamZam Bank", "ZMZ", 0xFF00695C, listOf("ZAMZAM")),
        Bank("hijra", "Hijra Bank", "HIJ", 0xFF2E7D6B, listOf("HIJRA")),
        Bank("tsehay", "Tsehay Bank", "TSE", 0xFFD84315, listOf("TSEHAY")),
        Bank("gadaa", "Gadaa Bank", "GAD", 0xFF558B2F, listOf("GADAA")),
        Bank("addis", "Addis International Bank", "AIB", 0xFFB71C1C, listOf("ADDISINT", "AIB")),
        Bank("ahadu", "Ahadu Bank", "AHA", 0xFF283593, listOf("AHADU")),
        Bank("goh", "Goh Betoch Bank", "GOH", 0xFF4E342E, listOf("GOH")),
        Bank("rammis", "Rammis Bank", "RAM", 0xFF455A64, listOf("RAMMIS")),
        Bank("shabelle", "Shabelle Bank", "SHA", 0xFF0277BD, listOf("SHABELLE")),
        Bank("tsedey", "Tsedey Bank", "TSD", 0xFFAD1457, listOf("TSEDEY"))
    )

    fun byId(id: String): Bank = all.firstOrNull { it.id == id }
        ?: Bank(id, id.uppercase(), id.take(3).uppercase(), 0xFF607D8B, emptyList())

    fun match(sender: String): Bank? {
        val s = sender.uppercase().filter { it.isLetterOrDigit() }
        if (s.isEmpty()) return null
        return all.firstOrNull { b ->
            b.aliases.any { a ->
                if (a.all { it.isDigit() }) s == a
                else s == a || s.startsWith(a) || (a.length >= 5 && s.contains(a))
            }
        }
    }
}
